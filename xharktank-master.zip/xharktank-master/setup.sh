#!/bin/bash

# This script must contain a series of commands to setup dependencies of your project to make it work.
# Eg:- For Java Gradle Project;

cd xharktank
chmod +x gradlew
./gradlew build
