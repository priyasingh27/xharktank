package com.api.exception;

public class PitchNotFoundException extends RuntimeException {
	public PitchNotFoundException(String msg) {
		super(msg);
	}
}
