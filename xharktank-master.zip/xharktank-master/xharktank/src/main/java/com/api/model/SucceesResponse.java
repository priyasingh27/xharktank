package com.api.model;

public class SucceesResponse {

	private final String id;

	public SucceesResponse(String id) {
		super();
		this.id = id;
	}

	public String getID() {
		return this.id;
	}
}
