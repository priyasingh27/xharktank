#!/bin/bash

# This script must contain a series of commands to run the backend application
# Eg:- For SpringBoot Project;

cd xharktank
./gradlew bootRun